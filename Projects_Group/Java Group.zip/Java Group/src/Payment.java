import java.util.Scanner;

class Payment {
    static Scanner sc = new Scanner(System.in);

    static boolean payment(int value,String pswd) {
        while (true) {
            System.out.println("ENTER \n 1 FOR UPI PAYMENT \n 2 FOR NET BANKING");
            System.out.println("ENTER CHOICE ");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    return (payByUpi(value,pswd));

                case 2:
                    sc.nextLine();
                    return (netBanking(value,pswd));

                default:
                    System.out.println("INVALID CHOICE");
                    break;
            }
        }
    }

    static boolean payByUpi(int value, String pswd) {
        System.out.println("ENTER UPI ID ");
        sc.nextLine();
        sc.nextLine();
        System.out.println("ENTER UPI PIN");
        sc.nextLine();
        int tries = 5;
        while (true) {
            if (tries == 0) {
                System.out.println("PAYMENT DECLINED!");
                return false;
            }
            System.out.println("Enter used registration password : ");
            String passcheck = sc.nextLine();
            if (passcheck.equalsIgnoreCase(pswd)) {
                while (true) {
                    System.out.println("ENTER 1 FOR CONFIRM PAYMENT OF : " + value);
                    int n = sc.nextInt();
                    if (n == 1) {
                        System.out.println("PAYMENT SUCCESSFUL");
                        return true;
                    } else {
                        System.out.println("INVALID NUMBER");
                        System.out.println("ENTER VALID NUMBER");
                    }
                }
            } else {
                System.out.println("Invalid Password!");
                System.out.println("Attempts left : " + (--tries));
            }
        }
    }

    static boolean netBanking(int value,String pswd) {
        String card, pin, cvv;
        int temp1 = 0, temp2 = 0, temp3 = 0;
        int tries = 5;
        while (true) {
            if (tries == 0) {
                System.out.println("Payment Declined");
                return false;
            }
            System.out.println("ENTER CARD NUMBER (Must be of 12 digits) :");
            card = sc.nextLine();
            System.out.println("ENTER PIN (Must be of 4 digits) : ");
            pin = sc.nextLine();
            System.out.println("ENTER CVV NUMBER (Must be of 3 digits) : ");
            cvv = sc.nextLine();
            System.out.println("Enter used registration password : ");
            String passcheck = sc.nextLine();
            char ch[] = card.toCharArray();
            char ch2[] = pin.toCharArray();
            char ch3[] = cvv.toCharArray();
            if (card.length() == 12 && pin.length() == 4 && cvv.length() == 3) {
                for (int i = 0; i < 12; i++) {
                    if (ch[i] >= '0' && ch[i] <= '9') {
                        temp1 = 1;
                    }
                }
                for (int i = 0; i < 4; i++) {
                    if (ch2[i] >= '0' && ch2[i] <= '9') {
                        temp2 = 1;
                    }
                }
                for (int i = 0; i < 3; i++) {
                    if (ch3[i] >= '0' && ch3[i] <= '9') {
                        temp3 = 1;
                    }
                }
            }
            if (temp1 == 1 && temp2 == 1 && temp3 == 1 && passcheck.equalsIgnoreCase(pswd)) {
                while (true) {
                    System.out.println("ENTER 1 FOR CONFIRM PAYMENT OF : " + value);
                    int n = sc.nextInt();
                    if (n == 1) {
                        System.out.println("PAYMENT SUCCESSFUL");
                        return true;
                    } else {
                        System.out.println("INVALID NUMBER");
                        System.out.println("Enter valid number!");
                    }
                }
            } else {
                System.out.println("INVALID DETAILS");
                System.out.println("Attempts left : " + (--tries));
            }
        }
    }
}